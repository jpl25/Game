﻿using UnityEngine;
using System.Collections;


namespace DungeonExplorer
{
	public class GetInventoryItem{
		private InventoryLoader inventory = new InventoryLoader();
		private Weapons wep;
		private Armor armor;
		private Item item;
		private Spells spell;

		public Weapons selectWeaponItem(int itemSlot){
			return inventory.getInventory ().selectWeapon (itemSlot);
		}

		public Armor selectArmorItem(int itemSlot){
			return inventory.getInventory ().selectArmor (itemSlot);
		}

		public Item selectItemItem(int itemSlot){
			return inventory.getInventory ().selectItem (itemSlot);
		}

		public Spells selectSpellItem(int itemSlot){
			return inventory.getInventory ().selectSpells (itemSlot);
		}

		//Spell selection method. loads the spell varable with the spell item
		public void selectSpell(int slotNum){
			spell = selectSpellItem (slotNum);
			if (spell != null) {Debug.Log ("You Selected: " + spell.getName () + " " + spell.getDamage ());}
		}

		//Weapon selection method. Loads the weapon varable withe the weapon item
		public void selectWeapon(int slotNum){
			wep = selectWeaponItem (slotNum);
			if (wep != null) {Debug.Log ("You Selected: " + wep.getName () + " " + wep.getDamage ());}
		}

		//Armor selection method. Loads the armor varable withe the armor item
		public void selectArmor(int slotNum){
			armor = selectArmorItem (slotNum);
			if (armor != null) {Debug.Log ("You Selected: " + armor.getName () + " " + armor.getDamage ());}
		}

		//Item selection method. Loads the item varable withe the  item
		public void selectItem(int slotNum){
			item = selectItemItem (slotNum);
			if (item != null) {Debug.Log ("You Selected: " + item.getName ());}
		}
	}
}

