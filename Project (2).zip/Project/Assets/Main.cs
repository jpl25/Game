﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine.UI;
using UnityEditor.SceneManagement;

namespace DungeonExplorer{
public class Main : MonoBehaviour {

		public int characterClass, ranNum;
		public InventoryLoader loadInventory = new InventoryLoader();
		public GetInventoryItem getInventoryItem = new GetInventoryItem();
		Inventory inv = new Inventory();


	// Use this for initialization
	void Start () {
			
			//ask for character class

			//This is just just to generate a character for testing
			int randomCharacterClass = Random.Range (1, 3);
			characterClass = randomCharacterClass;

			if (characterClass == 1) {
				Debug.Log ("You Are A Warrior!");
			}
			if (characterClass == 2) {
				Debug.Log ("You Are A Mage!");
			} 
			if (characterClass == 3) {
				Debug.Log ("You Are A Rouge!");
			}

			// Auto load the inventory
			loadInventory.setCharacterClass (randomCharacterClass);

			//This generates the random number for random loot encounter 
			//this is just for testing this will be in the fixed update method 
			//we will have a range from 1 to 1000 with 500 being the number that 
			// the random number will have to land on to prompt the random loot 

			//Debug.Log(loot.getRandomItemList (ranNum));
			ranNum = Random.Range (1, 10);
			//LootTextBody.text = loot.getRandomItemList (ranNum);

		
			//Display all items in inventory
			//displayInventoryItems ();

			//Select an Item out of an inventory slot
			getInventoryItem.selectItem(1);
			getInventoryItem.selectSpell (1);
			getInventoryItem.selectWeapon (1);
			getInventoryItem.selectArmor (1);


	}


	// Update is called once per frame
	void Update () {
			inv.displayInventoryItems ();
				
			}
		}
	}
