﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class InstanceController : MonoBehaviour
{
	public int characterCreation;
	public int mazeCrawling;
	public int inFight;
	public int loot;
	public int charIsMade;	
	public int charClass;
	//1 = Mage/2 = Warrior/3 = Rogue
	public int condition;
	//Use this to prevent Update() glitches
	//1 - 4 in this order: charCreation, maze, fight, loot
	public int fightStart;
	public int enemyHp;
	public int dice;

	public Camera hudCam;
	public Camera mazeCam;
	public Camera fightCam;
	
	public GameObject lootRoll;
	private GameObject lootGUI;
	private GameObject ccGUI;
	private GameObject fightGUI;
	private GameObject player;

	void Start ()
	{
		lootGUI = GameObject.Find("LootCanvas");
		ccGUI = GameObject.Find("CharCreateCanvas");
		fightGUI = GameObject.Find("BattleCanvas");
		characterCreation = 1;
		mazeCrawling = 0;
		inFight = 0;
		loot = 0;
		charIsMade = 0;
		fightStart = 0;

		hudCam.enabled = true;
		mazeCam.enabled = false;
		fightCam.enabled = false;
		
		fightGUI.GetComponent<Canvas>().enabled = false;
		lootGUI.GetComponent<Canvas>().enabled = false;
		ccGUI.GetComponent<Canvas>().enabled = true;
		
		player = GameObject.Find ("Player");
	}
	
	void Update()
	{
		if(dice < 51)
			condition = 2;

		if(dice > 74 && dice < 91 && condition != 3)
		{	
			characterCreation = 0;
			mazeCrawling = 0;
			inFight	= 1;
			loot = 0;
			fightStart = 1;
			condition = 3;
		}
		if(dice > 90 && dice < 101 && condition != 4)
		{
			characterCreation = 0;
			mazeCrawling = 0;
			inFight	= 0;
			loot = 1;
			condition = 4;
		}
		if(charIsMade == 1)
		{
			hudCam.enabled = false;
			mazeCam.enabled = true;
			ccGUI.GetComponent<Canvas>().enabled = false;
			mazeCrawling = 1;
			charIsMade = -1;
		}

		dice = player.GetComponent<EncounterGenerator> ().dice;
	}
	
	void FixedUpdate ()
	{
		if(loot == 1)
		{
			hudCam.enabled = true;
			mazeCam.enabled = false;
			fightCam.enabled = false;
			
			loot = 2;
			lootGUI.GetComponent<Canvas>().enabled = true;
			lootRoll.GetComponent<Image>().enabled = true;
			lootRoll.GetComponent<Button>().enabled = true;

			mazeCrawling = 0;
			inFight	= 0;
		}

		if(mazeCrawling == 1)
		{
			hudCam.enabled = false;
			mazeCam.enabled = true;
			fightCam.enabled = false;

			mazeCrawling = 2;

			inFight	= 0;
			loot = 0;
		}

		if(characterCreation == 1)
		{
			hudCam.enabled = true;
			mazeCam.enabled = false;
			fightCam.enabled = false;

			characterCreation = 2;
		}

		if(inFight == 1)
		{
			hudCam.enabled = false;
			mazeCam.enabled = false;
			fightCam.enabled = true;
			fightGUI.GetComponent<Canvas>().enabled = true;

			inFight = 2;

			mazeCrawling = 0;
				loot = 0;
		}
		
		if(fightStart == 1)
		{
			enemyHp = Random.Range(35, 57);
			fightStart = 2;
		}
	}

	public void removeCC()
	{
		if(charClass > 0)
			charIsMade = 1;		
	}

	public void RunFromBattle()
	{
		mazeCrawling = 1;
		fightGUI.GetComponent<Canvas>().enabled = false;
	}

	public void LootChosen()
	{
		mazeCrawling = 1;
		lootGUI.GetComponent<Canvas>().enabled = false;
	}

	public void setMage()
	{
		charClass = 1;
	}

	public void setWarrior()
	{
		charClass = 2;
	}

	public void setRogue()
	{
		charClass = 3;
	}
	//Void used to get rid of button that rolls for loot
	public void LootRoller()
	{
		lootRoll.GetComponent<Image>().enabled = false;
		lootRoll.GetComponent<Button>().enabled = false;
	}
	//Fight Controller
	public void Attack()
	{		
		int playerHit = 0;
		int enemyHit = 0;
		
		int playerInit = Random.Range(1, 20);
		int enemyInit = Random.Range(1, 20);
		
		if(Random.Range(1, 20) > 7)
			playerHit = 1;
		if(Random.Range(1, 20) > 10)
			enemyHit = 1;
		
		if(playerInit >= enemyInit)
		{
			if(playerHit == 1)
			{
				enemyHp = enemyHp - 10;
			}

			if(enemyHp <= 0)
			{
				mazeCrawling = 1;
				fightGUI.GetComponent<Canvas>().enabled = false;
				fightStart = 0;
			}
			//if(enemyHit == 1)
			//if(playerHp <= 0)
		}

		if(enemyInit > playerInit)
		{
			/*
			if(enemyHit == 1)
			if(playerHp <= 0)
			*/
			if(playerHit == 1)
			{
				enemyHp = enemyHp - 10;
			}

			if(enemyHp <= 0)
			{
				mazeCrawling = 1;
				fightGUI.GetComponent<Canvas>().enabled = false;
				fightStart = 0;
			}
		}
	}
}
