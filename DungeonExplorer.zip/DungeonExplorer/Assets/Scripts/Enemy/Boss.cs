﻿using UnityEngine;
using System.Collections;

public class Boss : MonoBehaviour
{
	public int maxHealth;
	public int health;
	public int dmg;
	
	void Start ()
	{
				
	}
	
	void Update ()
	{
	
	}
}
