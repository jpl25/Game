﻿using UnityEngine;
using System.Collections;

public class Goblin : MonoBehaviour
{
	public int maxHealth;
	public int health;
	public int dmg;
	
	void Start ()
	{
				
	}
	
	void Update ()
	{
	
	}
}
