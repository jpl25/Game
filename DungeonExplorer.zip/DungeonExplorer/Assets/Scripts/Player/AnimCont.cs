﻿using UnityEngine;
using System.Collections;

public class AnimCont : MonoBehaviour
{
	public int up;
	public int down;
	public int left;
	public int right;
	public Rigidbody2D rb2d;
	private Animator anim;

	void Start ()
	{
		anim = gameObject.GetComponent<Animator>();
		anim.SetFloat("Up", up);
		anim.SetFloat("Down", down);
		anim.SetFloat("Left", left);
		anim.SetFloat("Right", right);	
	}
	
	void Update ()
	{
		anim.SetFloat("Up", up);
		anim.SetFloat("Down", down);
		anim.SetFloat("Left", left);
		anim.SetFloat("Right", right);
	}

	void FixedUpdate ()
	{
		if(rb2d.velocity.y >= .1)
			up = 1;
		else
			up = 0;

		if(rb2d.velocity.y <= -.1)
			down = 1;
		else
			down = 0;

		if(rb2d.velocity.x >= .1)
			right = 1;
		else
			right = 0;

		if(rb2d.velocity.x <= -.1)
			left = 1;
		else
			left = 0;		
	}
}
