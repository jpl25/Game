﻿using UnityEngine;
using System.Collections;

public class Movement : MonoBehaviour
{
	
	public int speed = 75;
	private int setSpeed;
	public int camCheck;
	
	public GameObject instnceMngr;

	private BoxCollider2D bc2d;
	private Rigidbody2D rb2d;

	void Start ()
	{
		rb2d = gameObject.GetComponent<Rigidbody2D> ();
		bc2d = gameObject.GetComponent<BoxCollider2D> ();
		setSpeed = speed;
	}
	
	void Update ()
	{
		camCheck = instnceMngr.GetComponent<InstanceController>().mazeCrawling;
		if(camCheck > 0)
			speed = setSpeed;
		else
			speed = 0;		
	}

	void FixedUpdate ()
	{
		if (Input.GetKey (KeyCode.W)) 
			rb2d.AddForce ((Vector2.up * speed));
		
		if (Input.GetKey (KeyCode.A)) 
			rb2d.AddForce ((Vector2.left * speed));

		if (Input.GetKey (KeyCode.S)) 
			rb2d.AddForce ((Vector2.down * speed));

		if (Input.GetKey (KeyCode.D)) 
			rb2d.AddForce ((Vector2.right * speed));
	}
}
