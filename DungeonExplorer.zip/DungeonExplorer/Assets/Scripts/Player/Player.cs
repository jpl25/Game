﻿using UnityEngine;
using System.Collections;

public class Player : MonoBehaviour
{
	public double health;
	public double maxHealth;
	public double dmgMultiplier;
	public int charClass;

	void Start ()
	{
		maxHealth = 100;
		dmgMultiplier = 10;
		if(charClass == 1)//warrior
		{
			maxHealth = maxHealth * 1.4;
			dmgMultiplier = dmgMultiplier * .8;
		}

		if(charClass == 2)//mage
		{
			maxHealth = maxHealth * .8;
			dmgMultiplier = dmgMultiplier * 1.5;
		}

		if(charClass == 3)//rogue
		{
			maxHealth = maxHealth * .9;
			dmgMultiplier = dmgMultiplier * .9;
		}

	}
	
	void FixedUpdate ()
	{
			
	}
}
