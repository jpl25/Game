﻿using UnityEngine;
using System.Collections;

public class EncounterGenerator : MonoBehaviour
{
	public int dice;
	public float number;
	public float veloc;
	private Rigidbody2D rb2d;
	public int perc, first, second;
	
	void Start ()
	{
		rb2d = gameObject.GetComponent<Rigidbody2D> ();
		number = 0;
		dice = 0;
		perc = first%second;
	}
	
	void FixedUpdate ()
	{
		veloc = rb2d.velocity.y; 
		if(rb2d.velocity.y > 1 || rb2d.velocity.x > 1 || rb2d.velocity.y < -1 || rb2d.velocity.x < -1)		
			number = number + .05f;
		
		if(number > 3)
		{
			dice = Random.Range(1, 100);
			number = 0;
		}
	}
}
