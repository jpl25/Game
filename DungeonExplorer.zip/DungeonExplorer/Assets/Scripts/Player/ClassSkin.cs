﻿using UnityEngine;
using System.Collections;

public class ClassSkin : MonoBehaviour
{
	public int charClass;
	
	public GameObject mageSkin;
	public GameObject warriorSkin;
	public GameObject rogueSkin;
	public GameObject instanceMngr;

	void Start ()
	{
		mageSkin.GetComponent<SpriteRenderer>().enabled = false;
		warriorSkin.GetComponent<SpriteRenderer>().enabled = false;
		rogueSkin.GetComponent<SpriteRenderer>().enabled = false;
	}
	
	void Update ()
	{
		charClass = instanceMngr.GetComponent<InstanceController>().charClass;
			
		if(charClass == 1)
		{
			mageSkin.GetComponent<SpriteRenderer>().enabled = true;
			warriorSkin.GetComponent<SpriteRenderer>().enabled = false;
			rogueSkin.GetComponent<SpriteRenderer>().enabled = false;
		}
		if(charClass == 2)
		{
			mageSkin.GetComponent<SpriteRenderer>().enabled = false;
			warriorSkin.GetComponent<SpriteRenderer>().enabled = true;
			rogueSkin.GetComponent<SpriteRenderer>().enabled = false;
		}
		if(charClass == 3)
		{
			mageSkin.GetComponent<SpriteRenderer>().enabled = false;
			warriorSkin.GetComponent<SpriteRenderer>().enabled = false;
			rogueSkin.GetComponent<SpriteRenderer>().enabled = true;
		}
	}
}
